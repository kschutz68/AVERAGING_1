function [y L] = moving_average(u)
L = 50;
y = 0;
persistent first_time;
persistent dl;
if isempty(first_time)
    first_time = 0;
    dl = dsp.AsyncBuffer('Capacity',L);
end
y = (sum(peek(dl))+u)/(L+1);
write(dl,u);
