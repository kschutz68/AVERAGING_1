clc
clear moving_average
L = 3200;
x = ones(L,1) + rand(L,1) + [zeros(L/2,1);ones(L/2,1)];
for k = 1:length(x)
    [y(k) n] = moving_average(x(k));
end
xvec = 1:length(x);
figure;plot(xvec,x,'r',xvec,y,'b');grid on
legend('INPUT','MOVING AVG')
xlabel('sample')
title([num2str(n),' sample moving average'])

